#!/bin/bash

# =====================================================
# YAICO - VIBE CODE INITIALIZATION SCRIPT
# =====================================================
# This script prepares everything for Vibe Code sessions
# Run this BEFORE starting any Vibe Code session

set -e  # Exit on error

echo "🚀 Starting Yaico Project Setup..."

# 1. Create Next.js project
echo "📦 Creating Next.js 14 project with TypeScript..."
npx create-next-app@14 yaico \
  --typescript \
  --tailwind \
  --app \
  --src-dir \
  --import-alias "@/*" \
  --no-eslint

cd yaico

# 2. Install core dependencies
echo "📚 Installing core dependencies..."
npm install \
  firebase@10.7.0 \
  firebase-admin@12.0.0 \
  zod@3.22.4 \
  @google-cloud/kms@4.0.0 \
  @google-cloud/secret-manager@5.0.0 \
  @google/generative-ai@0.1.3 \
  stripe@14.10.0 \
  plaid@19.0.0

# 3. Install development dependencies
echo "🔧 Installing dev dependencies..."
npm install -D \
  vitest@1.1.0 \
  @testing-library/react@14.1.2 \
  @testing-library/user-event@14.5.1 \
  @vitest/ui@1.1.0 \
  @firebase/rules-unit-testing@3.0.1 \
  @types/node@20.10.5

# 4. Install monitoring & observability
echo "📊 Installing monitoring tools..."
npm install \
  @opentelemetry/api@1.7.0 \
  @opentelemetry/sdk-node@0.45.0 \
  @opentelemetry/auto-instrumentations-node@0.40.0 \
  pino@8.17.1 \
  pino-pretty@10.3.0

# 5. Initialize Firebase
echo "🔥 Initializing Firebase..."
firebase init \
  --project yaico-dev \
  firestore functions hosting emulators

# 6. Create project structure
echo "📁 Creating project structure..."
mkdir -p src/{app,components,lib,server,services,hooks,utils}
mkdir -p src/app/{api,dashboard,transactions,compliance,settings}
mkdir -p src/components/{ui,yaico,layouts}
mkdir -p src/lib/{types,security,tax,monitoring,constants}
mkdir -p src/server/{actions,gateways}
mkdir -p firebase/functions/src/{triggers,scheduled,http}
mkdir -p tests/{unit,integration,e2e,performance}
mkdir -p infrastructure/{terraform,docker}
mkdir -p docs/{api,architecture,deployment}

echo "✅ Project structure created!"
echo ""
echo "Next steps:"
echo "1. Copy the generated config files to your project"
echo "2. Set up your .env.local file"
echo "3. Start your first Vibe Code session"
echo ""
echo "Ready for Vibe Code! 🎉"
