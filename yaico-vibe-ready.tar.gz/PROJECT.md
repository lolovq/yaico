# YAICO - AI Financial Copilot for Dutch Freelancers

## 🎯 Project Overview
Yaico is a production-ready financial management SaaS platform specifically designed for Dutch freelancers (ZZP'ers). It uses AI to automate transaction categorization, monitors DBA compliance risks, and handles complex VAT calculations.

## 🏗️ Architecture

### Tech Stack
- **Frontend**: Next.js 14 (App Router), TypeScript, Tailwind CSS
- **Backend**: Firebase (Firestore, Cloud Functions, Auth)
- **AI**: Google Gemini API for categorization
- **Security**: Google Cloud KMS for encryption
- **Payments**: Stripe (subscriptions), Plaid (bank connections)
- **Monitoring**: OpenTelemetry, BigQuery analytics

### Core Mandates
1. **Aggregation** (2.A): Pre-calculate summaries for performance
2. **Async AI** (2.B): Background processing with Human-in-the-Loop
3. **Encryption** (2.C): KMS-based envelope encryption for sensitive data
4. **SaaS Gating** (4.2): Feature access based on subscription tier
5. **TDD** (3.A): Test-driven development with 80% coverage target

## 🔑 Key Features

### 1. AI Transaction Categorization
- Automatic categorization using Gemini AI
- Confidence scoring (>90% auto-approve, <90% human review)
- Learning from user corrections
- Dutch company recognition (KPN→utilities, AH→groceries)

### 2. DBA Compliance Monitoring
- Real-time client concentration tracking
- Risk scoring using Herfindahl-Hirschman Index
- Automated alerts when >70% income from one client
- Weekly compliance reports

### 3. VAT Calculation Engine
- Domestic & international transactions
- B2B/B2C classification
- Reverse charge mechanism
- OSS threshold monitoring

### 4. Performance Optimizations
- Multi-level aggregation (daily/monthly/quarterly/yearly)
- BigQuery for analytics
- Circuit breakers for external APIs
- Intelligent caching with TTL

## 📁 Project Structure

```
yaico/
├── src/
│   ├── app/                    # Next.js App Router pages
│   │   ├── api/                # API routes
│   │   ├── dashboard/          # Dashboard views
│   │   ├── transactions/       # Transaction management
│   │   └── compliance/         # DBA & tax compliance
│   ├── components/
│   │   ├── ui/                 # Reusable UI components
│   │   └── yaico/             # Business components
│   ├── lib/
│   │   ├── types/             # Zod schemas & TypeScript types
│   │   ├── security/          # Encryption services
│   │   ├── tax/               # VAT calculators
│   │   └── monitoring/        # Telemetry & logging
│   ├── server/
│   │   ├── actions/           # Server Actions
│   │   └── gateways/          # External API gateways
│   └── services/              # Business logic services
├── firebase/
│   └── functions/
│       └── src/
│           ├── triggers/      # Firestore triggers
│           ├── scheduled/     # Cron jobs
│           └── http/          # HTTP endpoints
├── tests/
│   ├── unit/                  # Unit tests
│   ├── integration/           # Integration tests
│   └── e2e/                   # End-to-end tests
└── infrastructure/
    └── terraform/             # Infrastructure as Code
```

## 🔐 Security Model

### Data Classification
- **PII**: Encrypted with KMS (bank tokens, personal data)
- **Financial**: Encrypted at rest, audit trail
- **Metadata**: Standard Firestore security

### Authentication Levels
- **Basic**: Read-only access, manual transactions
- **Professional**: AI features, bank sync, API access
- **Enterprise**: Team features, custom integrations

## 📊 Data Models

### Transaction
```typescript
{
  id: uuid
  userId: uuid
  amount: number
  description: string
  status: 'processing' | 'pending_review' | 'approved' | 'error'
  aiAnalysis?: {
    suggestedCategory: string
    certaintyScore: number
    modelVersion: string
  }
  taxDetails?: {
    vatRate: number
    vatAmount: number
    deductible: boolean
  }
}
```

### Client
```typescript
{
  id: uuid
  clientName: string
  classification: 'b2b' | 'b2c' | 'unknown'
  countryCode: string
  vatNumber?: string
  dbaTracking?: {
    totalInvoiced: number
    riskScore: number
  }
}
```

### Subscription
```typescript
{
  userId: uuid
  tier: 'starter' | 'professional' | 'enterprise'
  status: 'trialing' | 'active' | 'canceled'
  limits: {
    transactionsPerMonth: number
    clientsMax: number
    apiCallsPerDay: number
  }
}
```

## 🚀 Deployment Strategy

### Environments
1. **Local**: Firebase emulators + mock APIs
2. **Staging**: Full GCP integration, test data
3. **Production**: EU region, GDPR compliant

### CI/CD Pipeline
1. Security scanning (Snyk, TruffleHog)
2. Test suite (unit, integration, e2e)
3. Build & type checking
4. Deploy to staging
5. Smoke tests
6. Production deployment (with rollback)

## 📝 Coding Standards

### TypeScript
- Strict mode enabled
- Zod for runtime validation
- Explicit return types
- No `any` types

### Error Handling
```typescript
// Always use structured errors
return {
  status: 'error',
  code: 'PERMISSION_DENIED',
  userMessage: 'You need a Pro subscription',
  technicalDetails: { userId, tier }
}
```

### Testing
- Minimum 80% coverage
- Test business logic, not implementation
- Use factories for test data
- Integration tests for critical paths

## 🎯 Current Sprint Goals

### Week 1: Foundation
- [ ] Setup project structure
- [ ] Implement security layer (KMS)
- [ ] Create Zod schemas
- [ ] Setup gateway architecture

### Week 2: Core Features
- [ ] AI categorization flow
- [ ] Transaction management
- [ ] Basic aggregation

### Week 3: Compliance
- [ ] DBA monitoring
- [ ] VAT calculator
- [ ] Test coverage

### Week 4: Production
- [ ] Performance optimization
- [ ] Monitoring setup
- [ ] Deployment pipeline

## 🤖 Vibe Code Context

When implementing features, always consider:
1. **Security first**: Encrypt sensitive data
2. **Performance**: Use aggregation, avoid N+1 queries
3. **Compliance**: Dutch tax laws, GDPR
4. **Testing**: Write tests before implementation
5. **Monitoring**: Add telemetry for debugging

## 📚 Key Libraries Versions
- Next.js: 14.0.4
- Firebase: 10.7.0
- Zod: 3.22.4
- TypeScript: 5.3.3
- Gemini AI: 0.1.3

## 🔗 Important Links
- Figma: [Design System]
- Stripe Dashboard: [Test Mode]
- Firebase Console: [yaico-dev]
- GCP Console: [yaico-dev project]

---

**Note for Vibe Code**: This is a financial application handling sensitive data. Always prioritize security, use proper error handling, and ensure compliance with Dutch regulations. When in doubt, ask for clarification rather than making assumptions.
