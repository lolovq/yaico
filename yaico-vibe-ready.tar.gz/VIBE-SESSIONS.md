# YAICO - VIBE CODE IMPLEMENTATION SESSIONS

## 📋 Pre-Flight Checklist
- [ ] Run `yaico-vibe-setup.sh` script
- [ ] Copy `.env.example` to `.env.local`
- [ ] Set up Firebase project
- [ ] Copy `PROJECT.md` to project root
- [ ] Have this guide open while coding

---

## 🎯 SESSION 1: Data Contracts & Types (30 min)

### Command 1.1: Create Zod Schemas
```bash
vibe "Create comprehensive Zod schemas for Yaico financial platform. Read PROJECT.md first. Generate src/lib/types/schemas.ts with: 1) TransactionSchema with id, userId, amount, description, status enum (processing|pending_review|approved|error), aiAnalysis object with suggestedCategory and certaintyScore, taxDetails with vatRate and vatAmount. 2) ClientSchema with classification (b2b|b2c|unknown), countryCode, vatNumber with Dutch IBAN regex validation. 3) SubscriptionSchema with tier enum and usage limits. 4) AggregatedSummarySchema for performance optimization. Include Dutch-specific validations like BSN and KVK numbers. Add type exports."
```

### Command 1.2: Create Type Guards & Helpers
```bash
vibe "Create src/lib/types/guards.ts with TypeScript type guards and helper functions for the Zod schemas. Include: isValidDutchIBAN, isValidVATNumber, isValidKVKNumber, transaction status transition validators, and subscription tier permission checkers. Add comprehensive JSDoc comments."
```

---

## 🎯 SESSION 2: Security Infrastructure (45 min)

### Command 2.1: Encryption Service
```bash
vibe "Implement Google Cloud KMS encryption service in src/lib/security/encryption.service.ts. Read PROJECT.md section on Security Model. Create a service class that: 1) Uses envelope encryption with AES-256-GCM for data and KMS for key encryption. 2) Has methods encryptSensitiveData and decryptSensitiveData. 3) Includes proper error handling and telemetry. 4) Falls back to local encryption in development mode. Include TypeScript types for all methods."
```

### Command 2.2: Base Gateway Architecture
```bash
vibe "Create src/server/gateways/gateway.base.ts with production-ready base gateway class. Include: 1) GatewayResponse<T> interface with success, data, error, and metadata fields. 2) Abstract BaseGateway class with execute method that handles retries with exponential backoff, circuit breaker pattern, caching with TTL, and structured error responses. 3) OpenTelemetry tracing integration. Make it extensible for Stripe, Plaid, and AI gateways."
```

### Command 2.3: Audit Service
```bash
vibe "Create src/lib/security/audit.service.ts for compliance tracking. Implement audit trail that logs all sensitive operations to Firestore. Include methods for tracking: transaction modifications, VAT adjustments, DBA warnings, user permission changes. Each entry should have userId, action, timestamp, previousValue, newValue, and IP address. Add GDPR-compliant data retention policies."
```

---

## 🎯 SESSION 3: AI Integration (45 min)

### Command 3.1: Gemini AI Gateway
```bash
vibe "Create src/server/gateways/ai.gateway.ts extending BaseGateway. Implement transaction categorization using Google Gemini API. The suggestCategory method should: 1) Accept description and historical examples. 2) Build context from user's past transactions. 3) Return category, certainty score (0-1), reasoning, and alternatives. 4) Include Dutch company mappings (KPN→utilities, Albert Heijn→groceries). 5) Cache results by description hash. Use structured prompts for consistent JSON responses."
```

### Command 3.2: Categorization Cloud Function
```bash
vibe "Create firebase/functions/src/triggers/categorizeTransaction.ts Cloud Function. Trigger on transaction creation with status='processing'. Function should: 1) Get user's last 20 approved transactions for context. 2) Call AI gateway with circuit breaker protection. 3) If certaintyScore >= 0.90, set status='approved'. 4) If certaintyScore < 0.90, set status='pending_review' for human validation. 5) On error, set status='error' and schedule retry with exponential backoff. Include comprehensive logging."
```

### Command 3.3: Human-in-the-Loop UI
```bash
vibe "Create src/components/yaico/ValidationInbox.tsx React component for reviewing AI suggestions. Display transactions with status='pending_review'. For each transaction show: description, amount, AI suggested category with confidence score, alternative suggestions. Add 'Approve' and 'Change Category' buttons. Use React Hook Form for category changes. Include loading states and error handling. Style with Tailwind CSS using shadcn/ui components."
```

---

## 🎯 SESSION 4: Transaction Management (30 min)

### Command 4.1: Transaction Server Actions
```bash
vibe "Create src/server/actions/transaction.actions.ts with Next.js Server Actions. Implement: 1) createTransaction with SaaS gating (check subscription tier). 2) approveTransaction for human review. 3) getTransactions with pagination and filters. 4) bulkCategorize for multiple transactions. Each action should validate input with Zod, check permissions, handle errors with structured responses, and emit telemetry events."
```

### Command 4.2: Transaction Service
```bash
vibe "Create src/services/transaction.service.ts business logic layer. Implement methods for: transaction CRUD operations, status transitions with validation, category learning (store user corrections), bulk import from CSV/bank statements. Include transaction duplicate detection using description hashing. Add methods for calculating running balances and cash flow projections."
```

---

## 🎯 SESSION 5: Aggregation System (45 min)

### Command 5.1: Aggregation Cloud Functions
```bash
vibe "Create firebase/functions/src/triggers/updateAggregations.ts that triggers when transaction status changes to 'approved'. Update multiple aggregation levels atomically: daily, monthly, quarterly, yearly summaries. For each level, track: totalIncome, totalExpenses, incomeByCategory, expensesByCategory, vatCollected, vatPaid. Use FieldValue.increment for atomic updates. Include client concentration metrics for DBA monitoring."
```

### Command 5.2: Dashboard Summary Component
```bash
vibe "Create src/components/yaico/DashboardSummary.tsx that displays aggregated data. NEVER query transactions directly. Fetch from pre-calculated summaries. Show: YTD income, YTD expenses, tax reserved (in mint green #00CC99), top spending categories (pie chart), monthly trend (line chart). Use Recharts for visualizations. Include loading skeletons and error boundaries."
```

---

## 🎯 SESSION 6: DBA Compliance (45 min)

### Command 6.1: DBA Risk Calculator
```bash
vibe "Create firebase/functions/src/scheduled/dbaMonitor.ts scheduled Cloud Function running weekly. Calculate DBA risk by: 1) Aggregating revenue per client last 12 months. 2) Calculate percentage from top client. 3) Calculate Herfindahl-Hirschman Index for diversity score. 4) Determine risk level: <50% low, 50-70% medium, 70-85% high, >85% critical. 5) Generate Dutch-language recommendations. Store results in dba_monitoring collection."
```

### Command 6.2: DBA Alert System
```bash
vibe "Create src/server/actions/compliance.actions.ts with DBA monitoring actions. Implement: getDBAStatus returning current risk metrics, dismissDBAWarning with reason logging, getDBAHistory for trend analysis. When risk is high/critical, send email alerts and in-app notifications. Include methods for generating modelovereenkomst suggestions based on client relationships."
```

### Command 6.3: Compliance Dashboard
```bash
vibe "Create src/app/compliance/dba/page.tsx Next.js page for DBA monitoring. Display: client concentration pie chart, risk level indicator (green/yellow/red), top 5 clients table, historical risk trend, actionable recommendations in Dutch. Add export functionality for accountant reports. Style with Tailwind using warning colors for high risk scenarios."
```

---

## 🎯 SESSION 7: VAT Engine (45 min)

### Command 7.1: VAT Calculator
```bash
vibe "Create src/lib/tax/vatCalculator.ts with comprehensive VAT logic. Support: 1) Dutch domestic transactions (21% standard, 9% reduced). 2) EU B2B with reverse charge (0% with valid VAT number). 3) EU B2C with OSS threshold checking. 4) Non-EU exports (0%). Include VAT number validation using VIES format patterns. Add methods for quarterly VAT return calculations and ICL reporting requirements."
```

### Command 7.2: VAT Integration Tests
```bash
vibe "Create tests/unit/tax/vatCalculator.test.ts with comprehensive test cases. Test scenarios: NL B2C (21% VAT), NL B2B (21% VAT), DE B2B with VAT number (0% reverse charge), FR B2C digital services (French VAT rate), US export (0% VAT). Include edge cases for invalid VAT numbers and missing client data. Aim for 100% code coverage."
```

---

## 🎯 SESSION 8: Payment Integration (30 min)

### Command 8.1: Stripe Gateway
```bash
vibe "Create src/server/gateways/stripe.gateway.ts extending BaseGateway. Implement: createCheckoutSession for subscriptions, handleWebhook for payment events, createPortalSession for billing management, generatePaymentLink for invoices. In development/sandbox mode, return mock responses without API calls. Include proper error handling and webhook signature verification."
```

### Command 8.2: Subscription Management
```bash
vibe "Create src/server/actions/subscription.actions.ts for SaaS management. Implement: upgradeSubscription with proration, downgradeSubscription with feature removal, pauseSubscription for temporary holds, getUsageMetrics comparing current usage vs limits. Include subscription state machine validating allowed transitions. Add usage-based billing calculations for API calls."
```

---

## 🎯 SESSION 9: Testing & Quality (45 min)

### Command 9.1: Integration Test Suite
```bash
vibe "Create tests/integration/transaction-flow.test.ts testing complete transaction lifecycle. Test: 1) Creation triggers AI categorization. 2) High confidence auto-approves. 3) Low confidence requires review. 4) Approval triggers aggregation. 5) SaaS gating blocks basic users. Use Firebase emulators and mock external APIs. Include performance assertions (response time <100ms)."
```

### Command 9.2: E2E Tests
```bash
vibe "Create tests/e2e/user-journey.spec.ts Playwright test for critical user journey: sign up, add bank connection, import transactions, review AI suggestions, check DBA status, generate tax report. Test both happy path and error scenarios. Include accessibility tests and mobile viewport testing."
```

---

## 🎯 SESSION 10: Monitoring & DevOps (30 min)

### Command 10.1: Telemetry Setup
```bash
vibe "Create src/lib/monitoring/telemetry.ts with OpenTelemetry configuration. Set up: traces for API calls and database queries, custom metrics for business KPIs (transactions processed, AI accuracy, DBA risk levels), structured logging with correlation IDs. Export to Google Cloud Trace in production, console in development."
```

### Command 10.2: GitHub Actions Pipeline
```bash
vibe "Create .github/workflows/deploy.yml multi-stage deployment pipeline. Stages: 1) Security scanning with Snyk. 2) Run all test suites with coverage. 3) Build and type check. 4) Deploy to staging on push to main. 5) Run smoke tests. 6) Deploy to production with manual approval. Include rollback on failure and Slack notifications."
```

---

## 🎯 SESSION 11: Performance Optimization (30 min)

### Command 11.1: API Response Caching
```bash
vibe "Create src/lib/cache/redis-cache.ts caching layer. Implement: in-memory cache for development, Redis for production, cache invalidation strategies, TTL based on data type (aggregations: 1 hour, AI suggestions: 24 hours, user data: 5 minutes). Add cache warming for frequently accessed data."
```

### Command 11.2: Database Indexes
```bash
vibe "Create firebase/firestore.indexes.json with composite indexes for common queries: transactions by userId and status, transactions by userId and date range, clients by userId ordered by revenue, aggregations by userId and period. Include security rules in firestore.rules enforcing user data isolation."
```

---

## 🎯 SESSION 12: Final Polish (30 min)

### Command 12.1: Error Boundary
```bash
vibe "Create src/components/ErrorBoundary.tsx React Error Boundary. Catch and log errors to monitoring service. Display user-friendly error messages in Dutch. Include 'Try Again' button and support contact. For development, show full error stack. Add Sentry integration for production error tracking."
```

### Command 12.2: Loading Experience
```bash
vibe "Create src/components/ui/Skeleton.tsx loading skeleton components. Implement skeletons for: transaction list, dashboard cards, charts, forms. Use Tailwind's animate-pulse. Create a LoadingProvider that coordinates loading states across components. Add progressive loading for better perceived performance."
```

---

## 📝 Post-Implementation Checklist

### Testing
- [ ] All tests passing
- [ ] Coverage > 80%
- [ ] E2E tests running
- [ ] Performance benchmarks met

### Security
- [ ] Environment variables secured
- [ ] API keys in Secret Manager
- [ ] Encryption working
- [ ] Audit trail active

### Compliance
- [ ] DBA monitoring active
- [ ] VAT calculations correct
- [ ] GDPR compliant
- [ ] Data retention policies set

### Performance
- [ ] Aggregations working
- [ ] Caching implemented
- [ ] Indexes created
- [ ] <100ms response times

### Monitoring
- [ ] Telemetry active
- [ ] Alerts configured
- [ ] Logging structured
- [ ] Dashboards created

---

## 🚨 Common Issues & Solutions

### Issue: Firebase emulators not starting
```bash
# Kill existing processes
lsof -ti:8080 | xargs kill
lsof -ti:9099 | xargs kill
# Restart emulators
npm run firebase:emulators
```

### Issue: TypeScript errors
```bash
# Clear cache and rebuild
rm -rf .next
rm -rf node_modules/.cache
npm run build
```

### Issue: Test failures
```bash
# Run tests in isolation
npm run test -- --run --no-coverage
# Check for timing issues
npm run test -- --testTimeout=10000
```

---

## 🎉 Completion

After all sessions, you'll have:
- Production-ready SaaS platform
- AI-powered categorization
- DBA compliance monitoring
- International VAT support
- 80%+ test coverage
- Full observability
- Automated deployment

**Total implementation time: ~8 hours across 12 sessions**

Ready to start? Begin with Session 1! 🚀
