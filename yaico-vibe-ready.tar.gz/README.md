# 🚀 YAICO - Vibe Code Ready Project

## ⚡ Quick Start for Vibe Code

### 1️⃣ Initial Setup (5 minutes)
```bash
# Clone or create project directory
mkdir yaico && cd yaico

# Copy all provided files to project root
# - package.json
# - tsconfig.json
# - vitest.config.ts
# - firebase.json
# - firestore.rules
# - firestore.indexes.json
# - .env.example → .env.local
# - PROJECT.md
# - VIBE-SESSIONS.md

# Install dependencies
npm install

# Initialize Firebase (select existing project or create new)
firebase init
```

### 2️⃣ Environment Setup
```bash
# Copy and configure environment
cp .env.example .env.local

# Edit .env.local with your keys:
# - Firebase config (from Firebase Console)
# - Gemini API key (from Google AI Studio)
# - Stripe keys (from Stripe Dashboard)
```

### 3️⃣ Start Vibe Code Sessions

Open terminal and run your first Vibe Code command:

```bash
vibe "Create comprehensive Zod schemas for Yaico financial platform. Read PROJECT.md first..."
```

Follow the commands in `VIBE-SESSIONS.md` sequentially.

## 📁 Project Structure

```
yaico/
├── src/
│   ├── app/           # Next.js pages
│   ├── components/    # React components
│   ├── lib/          # Core libraries
│   ├── server/       # Server-side code
│   └── services/     # Business logic
├── firebase/         # Cloud Functions
├── tests/           # Test suites
└── docs/           # Documentation
```

## 🎯 Implementation Order

1. **Foundation** (Session 1-2): Types & Security
2. **AI Core** (Session 3): Categorization
3. **Business Logic** (Session 4-5): Transactions & Aggregation
4. **Compliance** (Session 6-7): DBA & VAT
5. **Integration** (Session 8): Payments
6. **Quality** (Session 9-11): Testing & Monitoring
7. **Polish** (Session 12): UX & Error Handling

## 🔧 Development Commands

```bash
# Development
npm run dev              # Start Next.js dev server
npm run firebase:emulators  # Start Firebase emulators

# Testing
npm run test            # Run all tests
npm run test:watch      # Watch mode
npm run test:coverage   # Coverage report

# Building
npm run build          # Production build
npm run type-check     # TypeScript validation

# Deployment
npm run firebase:deploy  # Deploy to Firebase
```

## 🏗️ Architecture Decisions

- **Next.js 14 App Router**: Modern React with Server Components
- **Firebase Suite**: Scalable backend without server management
- **Zod Validation**: Runtime type safety
- **Server Actions**: Type-safe API without REST endpoints
- **Google Cloud KMS**: Enterprise-grade encryption
- **OpenTelemetry**: Production observability

## 🔐 Security Features

- Envelope encryption for sensitive data
- Row-level security in Firestore
- API rate limiting per subscription tier
- Audit trail for compliance
- Automatic PII redaction in logs

## 📊 Performance Targets

- Response time: <100ms p95
- AI categorization: <2s
- Dashboard load: <500ms
- Test coverage: >80%
- Lighthouse score: >90

## 🚨 Critical Paths to Test

1. User signup → Subscription → First transaction
2. Bank import → AI categorization → Human review
3. Month end → Tax calculation → Report generation
4. High DBA risk → Alert → Compliance action

## 💡 Vibe Code Tips

1. **Always read PROJECT.md first** - It has critical context
2. **Follow session order** - Later sessions depend on earlier ones
3. **Test after each session** - Catch issues early
4. **Use emulators** - Don't test on production
5. **Commit often** - Easy rollback if needed

## 🆘 Troubleshooting

### Firebase emulators won't start
```bash
# Kill zombie processes
pkill -f firebase
# Clear emulator data
rm -rf .firebase/
# Restart
npm run firebase:emulators
```

### TypeScript errors after Vibe Code
```bash
# Regenerate types
npm run type-check
# Clear Next.js cache
rm -rf .next
npm run dev
```

### Tests failing
```bash
# Run specific test
npm run test -- transaction.test.ts
# Verbose output
npm run test -- --reporter=verbose
```

## 📚 Resources

- [Next.js 14 Docs](https://nextjs.org/docs)
- [Firebase Documentation](https://firebase.google.com/docs)
- [Zod Documentation](https://zod.dev)
- [Dutch Tax Authority](https://www.belastingdienst.nl/wps/wcm/connect/bldcontenten/belastingdienst/business/vat/)
- [GDPR Compliance](https://gdpr.eu/)

## 🎉 Ready to Build!

You now have everything needed to build Yaico with Vibe Code.
Start with Session 1 in `VIBE-SESSIONS.md` and build feature by feature.

**Expected total build time: ~8 hours across 12 sessions**

Good luck! 🚀
